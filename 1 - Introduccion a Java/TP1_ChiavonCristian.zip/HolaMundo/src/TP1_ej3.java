public class TP1_ej3 {
   
    public static void main(String[] args) {
   
        // Declaracion de variables
        String nombre = "Cristian";
        int edad = 39;
        double altura = 1.73;
        boolean estudiante = true;
        
        //Muestra en pantalla
        System.out.println(nombre);
        System.out.println(edad);
        System.out.println(altura);
        System.out.println(estudiante);
                
    }
    
}
