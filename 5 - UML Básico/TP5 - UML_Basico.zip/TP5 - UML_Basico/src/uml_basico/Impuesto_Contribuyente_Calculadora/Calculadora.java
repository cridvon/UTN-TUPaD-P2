package uml_basico.Impuesto_Contribuyente_Calculadora;

public class Calculadora {

    public void calcular(Impuesto impuesto) {
        System.out.println("Se aplica impuesto: " + impuesto);
    }

}
