package uml_basico.Reproductor_Cancion_Artista;

public class Reproductor {

    public void reproducir(Cancion cancion) {
        System.out.println("Reproduciendo: " + cancion);
    }

}
